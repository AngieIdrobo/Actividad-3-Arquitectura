
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Servidor {
    public static void main (String[] arg){
    
            ServerSocket server = null;
            Socket scliente = null;
            DataInputStream in;
            DataOutputStream out;
            
            final int Puerto = 4500;
        
        try {    
            server = new ServerSocket (Puerto);
            System.out.println("Server started");
            
            while(true){
            scliente = server.accept();
            
                System.out.println("Connected Customer");
            in = new DataInputStream (scliente.getInputStream());
            out = new DataOutputStream (scliente.getOutputStream());
            
            String aviso = in.readUTF();
            
                System.out.println(aviso);
                
                out.writeUTF("Message from the server");
            
                scliente.close();
                System.out.println("Disconnected customer");
            }
        
               
        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
