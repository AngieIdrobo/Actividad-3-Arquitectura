
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Cliente {
    public static void main (String [] arg){
    
        
            final String lhost = "127.0.0.1";
            final int Puerto = 4500;
            DataInputStream in;
            DataOutputStream out;
            
        try {    
            Socket scliente = new Socket(lhost, Puerto);
        
            in = new DataInputStream (scliente.getInputStream());
            out = new DataOutputStream (scliente.getOutputStream());
            
            out.writeUTF("Message from the customer");
            
            String aviso = in.readUTF();
            System.out.println(aviso);
            
            scliente.close();
        
        
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
